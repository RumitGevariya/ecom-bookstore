from django.shortcuts import render,HttpResponseRedirect,redirect,get_object_or_404
from django.views.decorators.csrf import csrf_exempt
from PAYMENT import Checksum
from CART.models import ORDER_PLACE_DETAILS
from AUTH.models import Register

# Create your views here.

MERCHANT_KEY ='enter your key'
MERCHANT_ID = 'enter your id'

@csrf_exempt
def handlerequest(request):
    # paytm will send you post request here
    form = request.POST
    response_dict = {}
    for i in form.keys():
        response_dict[i] = form[i]
        if i == 'CHECKSUMHASH':
            checksum = form[i]
    print(response_dict)

    verify = Checksum.verify_checksum(response_dict, MERCHANT_KEY, checksum)
    if verify:
        if response_dict['RESPCODE'] == '01':
            print('order successful')
            orderid =response_dict['ORDERID']
            data1 = get_object_or_404(ORDER_PLACE_DETAILS, Orderid=orderid)
            userid = data1.Userid
            user = get_object_or_404(Register, UserId=userid)
            TXNID =response_dict['TXNID']
            PAYMENTMODE =response_dict['PAYMENTMODE']
            STATUS =response_dict['STATUS']
            BANKTXNID =response_dict['BANKTXNID']
            data1.TXNID =TXNID
            data1.PAYMENTMODE =PAYMENTMODE
            data1.STATUS =STATUS
            data1.BANKTXNID =BANKTXNID
            # data1.save()
            file = open(f'media/invoice/{TXNID}.txt', 'w')
            file.write("TXNID:" + TXNID)
            file.close()
            print('file make')
            file = f'invoice/{TXNID}.txt'
            data1.invoice = file
            data1.save()
            print('save done')
            data2 = get_object_or_404(ORDER_PLACE_DETAILS, Orderid=orderid)
            return render(request,'PAYMENT/invoice.html',{'user':user,'orderdata':data2})
        else:
            print('order was not successful because' + response_dict['RESPMSG'])
    return render(request, 'PAYMENT/invoice.html', {'response': response_dict})

