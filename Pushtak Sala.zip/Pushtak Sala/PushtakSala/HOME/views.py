from django.shortcuts import render,get_object_or_404
from PRODUCT.models import Books
from AUTH.models import Register
from AUTH import views
from CART import models


# Create your views here.
def INDEX(request):
    NewArrival = Books.objects.all()

    ##for a subscriber....
    if request.method =='POST':
        email =request.POST['email']
        message ='Now You are our subscriber'
        views.SendEmail(email,message)
        print('subscriber done')

    if request.session.has_key('UserId'):
        data1 = get_object_or_404(Register, UserId=request.session['UserId'])
        return render(request,'HOME/index-18.html',{'NewArrival':NewArrival,'data':data1})
    else:
        return render(request, 'HOME/index-18.html', {'NewArrival': NewArrival})


def Blog_Details(request):
    blogcomment =models.Blog_Comments.objects.all()
    ###if person add comment..
    if request.method =='POST':
        name =request.POST['username']
        comment =request.POST['massage']
        img =request.FILES.get('img')
        models.Blog_Comments(name=name,comment =comment,image =img).save()

    if request.session.has_key('UserId'):
        data1 = get_object_or_404(Register, UserId=request.session['UserId'])
        return render(request, 'HOME/blog-details.html', {'data':data1,'blogcomment': blogcomment})
    else:
        return render(request, 'HOME/index-18.html', {'blogcomment': blogcomment})




def Blog(request):
    if request.session.has_key('UserId'):
        data1 = get_object_or_404(Register, UserId=request.session['UserId'])
        return render(request, 'HOME/blog.html',{'data':data1})
    else:
        return render(request, 'HOME/blog.html')

def About(request):
    if request.session.has_key('UserId'):
        data1 = get_object_or_404(Register, UserId=request.session['UserId'])
        return render(request, 'HOME/about.html',{'data':data1})
    else:
        return render(request, 'HOME/about.html')
