from django.urls import path
from .views import *
urlpatterns = [
    path('',INDEX, name ='home'),
    path('blog-details/',Blog_Details , name ='blog-details'),
    path('blog/',Blog, name ='blog'),
    path('about/',About ,name ='about'),
]