from django.shortcuts import render,get_object_or_404,redirect
from django.urls import reverse
from AUTH.models import Register
from PRODUCT.models import Books
from .models import CART,ORDER_PLACE_DETAILS
from  AUTH import views
from PAYMENT import Checksum


MERCHANT_KEY ='enter your key'
MERCHANT_ID = 'enter your id'
# Create your views here.

### create orderid....
def Create_OrderId():
    import random
    a = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    orderid = ''.join(random.sample(a, 15))
    return orderid

###cart page...
def Cart_Page(request):
    if request.session.has_key('UserId'):
        ##get login user data from registor datas..
        profile = get_object_or_404(Register, UserId=request.session['UserId'])
        user_cart =CART.objects.filter(Userid =request.session['UserId'])
        a = 0
        for i in user_cart:
            a = float(i.Book_Price) + a
        return render(request, 'CART/cart.html',{'data':profile,'cart_product':user_cart,'a':a})
    else:
        return render(request,'CART/cart.html')

def Add_To_Cart(request,i):
    if request.session.has_key('UserId'):
        profile = get_object_or_404(Register, UserId=request.session['UserId'])
        ###find a login user id...
        Userid = profile.UserId
        ### find a perticuler id books from the books tables
        cart_product = get_object_or_404(Books, pk=i)
        Book_Image = cart_product.Book_Image
        Book_Name = cart_product.Book_Name
        Book_Price = cart_product.Book_Offer_Price
        CART(Userid=Userid, Book_Image=Book_Image, Book_Name=Book_Name, Book_Price=Book_Price).save()
        return redirect('cart')
    else:
        return redirect('login')




def Delete_Cart_Product(request,i):
    ###find the perticuler id book from the cart tables..
    product =get_object_or_404(CART,pk =i)
    product.delete()
    return redirect('cart')


###buy products page...
def Checkout_Page(request):
    if request.session.has_key('UserId'):
        profile = get_object_or_404(Register, UserId=request.session['UserId'])
        UserId =profile.UserId
        Email = profile.Email
        ###for a billing perpose..
        cart_product =CART.objects.filter(Userid =request.session['UserId'])
        a =0
        for i in cart_product:
            a =float(i.Book_Price)+a
        price =a
        gst_charge ='18%'
        gst_price = (price * (18 / 100))
        total = price + (gst_price)
        print(total)
        ###if user place the order then below function run...
        if request.method =='POST':
            import datetime
            Orderid = Create_OrderId()
            name =request.POST['firstname'] + request.POST['lastname']
            address =request.POST['address']
            city =request.POST['city']
            email =request.POST['email']
            phone =request.POST['phone']
            date =datetime.datetime.now()
            Total =total
            details =[]
            for i in cart_product:
                details.append(i.Book_Name)
                details.append(i.Book_Price)
            product_details =','.join(details)
            message = ('Thanku For Your Order' +'\n' +'OrderId:' + Orderid +'\n' + name + '\n'  + address +'\n'  + city +'\n'  + Email +'\n'  + phone +'\n'  +  product_details )
            Qrcode(message,Orderid)
            img = f'qrcode/{Orderid}.png'
            ORDER_PLACE_DETAILS(Userid =UserId ,Orderid =Orderid ,Order_Details =product_details,Date =date,qrcode =img,Total =Total).save()
            param_dict = {
                'MID': MERCHANT_ID,
                'ORDER_ID':str(Orderid),
                'TXN_AMOUNT':str(Total),
                'CUST_ID':email,
                'INDUSTRY_TYPE_ID': 'Retail',
                'WEBSITE': 'WEBSTAGING',
                'CHANNEL_ID': 'WEB',
                'CALLBACK_URL':'http://127.0.0.1:8000/handlerequest/',
            }
            param_dict['CHECKSUMHASH'] = Checksum.generate_checksum(param_dict, MERCHANT_KEY)
            # views.SendEmail(Email, message)
            print(param_dict['CHECKSUMHASH'])
            return render(request, 'PAYMENT/paytm.html', {'param_dict': param_dict ,'name':name})
        return render(request,'CART/checkout.html',{'data':profile,'cart_product':cart_product,'a':price})
    else:
        return redirect('login')


### for a compareing a products..
def Compare_Page(request):
    return render(request,'CART/compare.html')


##create a order QR Code....
def Qrcode(message,Orderid):
    import qrcode
    qr = qrcode.QRCode(
        version=1,
        box_size=10,
        border=4,
    )
    qr.add_data(message)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    img.save(f'media/qrcode/{Orderid}.png')

