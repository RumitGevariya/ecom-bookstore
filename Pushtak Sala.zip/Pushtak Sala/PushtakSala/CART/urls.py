from django.urls import path
from .views import *
urlpatterns = [
    path('Cart/',Cart_Page, name ='cart'),
    path('add-to-cart/<i>/',Add_To_Cart, name ='cartdetails'),
    path('delete-cart-product/<i>/',Delete_Cart_Product ,name ='delete'),
    path('Check-Out/', Checkout_Page, name='checkout'),
    path('compare/',Compare_Page ,name ='compare'),
]