from django.db import models

# Create your models here.
class CART(models.Model):
    Userid =models.CharField(max_length=200)
    Book_Image =models.ImageField(upload_to='rumit',blank=True)
    Book_Name =models.CharField(max_length=200)
    Book_Price =models.CharField(max_length=200)
    Quantity =models.PositiveIntegerField(default=0)
    Total =models.PositiveIntegerField(default=0)


class ORDER_PLACE_DETAILS(models.Model):
    Userid =models.CharField(max_length=200)
    Orderid =models.CharField(max_length=200)
    Order_Details =models.TextField()
    Date =models.CharField(max_length=200,default='')
    qrcode = models.ImageField(default='', blank=True)
    Total =models.IntegerField(default=0)
    TXNID = models.CharField(max_length=200, default='')
    PAYMENTMODE = models.CharField(max_length=200, default='')
    STATUS = models.CharField(max_length=200, default='')
    BANKTXNID = models.CharField(max_length=200, default='')
    invoice =models.FileField(default='')


class Blog_Comments(models.Model):
    name =models.CharField(max_length=200)
    image =models.ImageField(upload_to='commentperson',blank=True)
    comment =models.TextField()
    date =models.DateTimeField(auto_now_add=True)