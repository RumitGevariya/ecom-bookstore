from django.contrib import admin
from .models import *
# Register your models here.
class AdminCart(admin.ModelAdmin):
    list_display = ['Userid','Book_Image','Book_Name','Book_Price','Quantity','Total']
admin.site.register(CART, AdminCart)

class AdminOrder(admin.ModelAdmin):
    list_display = ['Userid','Orderid','Date','qrcode']
admin.site.register(ORDER_PLACE_DETAILS,AdminOrder)

admin.site.register(Blog_Comments)