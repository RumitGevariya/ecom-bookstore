from django.shortcuts import render,redirect,get_object_or_404
from .models import *
from django.contrib import messages
from CART.models import ORDER_PLACE_DETAILS
from django.db.models import Q
# Create your views here.


def SendEmail(TO,MESSAGE):
    import smtplib
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()
    server.login('bansupatel008@gmail.com', 'shruti987@')
    server.sendmail('bansupatel008@gmail.com',TO, MESSAGE)
    print('done email')
    server.quit()

def Create_Username():
    import random
    a = '0123456789'
    b = ''.join(random.sample(a, 10))
    return b

def LOGIN_PAGE(request):
    if request.method == 'POST':
        try:
            r = Register.objects.get(UserId =request.POST.get('email'))
            if r.Password == request.POST.get('password'):
                print("done")
                request.session['UserId'] =request.POST.get('email')
                print(request.session['UserId'])
                print('sesssion created')
                return redirect('home')
            else:
                messages.info(request, 'password Wrong')
        except:
            messages.info(request, 'UserID  Wrong')
    return render(request, 'AUTH/login.html')


def REGISTER_PAGE(request):
    if request.method == 'POST':
        first_name = request.POST.get('first name')
        last_name = request.POST.get('last name')
        Email = request.POST.get('email')
        phone =request.POST.get('phone')
        country =request.POST.get('country')
        address =request.POST.get('address1') + request.POST.get('address2')
        city =request.POST.get('city')
        state =request.POST.get('state')
        pincode =request.POST.get('pincode')
        profile_img =request.FILES.get('img')
        password =request.POST.get('password')
        conform_password =request.POST.get('confirm password')
        if password == conform_password:
            if Register.objects.filter(Email =Email).exists():
                messages.info(request,'Email Alredy Exists')
            else:
                userid =Create_Username()
                message =(first_name + 'your UserId Is ' + userid)
                SendEmail(Email,message)
                Register(First_Name=first_name, Last_Name=last_name, Email=Email, Phone=phone, Country=country,
                         Address=address, City=city, State=state, PinCode=pincode, Password=password ,UserId =userid,Profile_Image=profile_img).save()
                return redirect('login')
        else:
            messages.info(request, 'Password Doesnot Match')
    return render(request, 'AUTH/register.html')


def LOGOUT_PAGE(request):
    if request.session.has_key('UserId'):
        del request.session['UserId']
        return redirect('login')
    else:
        return redirect('login')


def MYACCOUNT_PAGE(request):
    if request.session.has_key('UserId'):
        data1 = get_object_or_404(Register, UserId=request.session['UserId'])
        try:
            temp =0
            Oreder_data =ORDER_PLACE_DETAILS.objects.filter(Userid=request.session['UserId'])
        except:
            temp =1

        if request.method =='POST':
            first_name =request.POST.get('first name')
            last_name =request.POST.get('last name')
            profile_Image =request.FILES.get('img')
            email =request.POST.get('email')
            current_password = request.POST.get('current password')
            data1 = get_object_or_404(Register, UserId=request.session['UserId'])
            data1.First_Name = first_name
            data1.Last_Name =last_name
            data1.Profile_Image =profile_Image
            data1.Email =email
            data1.Password =current_password
            data1.save()
            print('change succesfully')
            return render(request, 'AUTH/my-account.html', {'data': data1})
        if temp ==1:
            return render(request, 'AUTH/my-account.html',{'data': data1})
        else:
            return render(request, 'AUTH/my-account.html', {'data': data1, 'Oreder_data': Oreder_data})
    else:
        return redirect('login')


def CONTACT_PAGE(request):
    if request.method == 'POST':
        Name = request.POST.get('name')
        Email = request.POST.get('email')
        Subject = request.POST.get('subject')
        Messages = request.POST.get('message')
        Contact(Name=Name, Email=Email, Subject=Subject, Message=Messages).save()
        MESSAGE = ('Hello' + Name + ' Thankyou For The Visited Our Store..Our Team will Contect  You Shortly')
        try:
            SendEmail(Email, MESSAGE)
        except:
            return redirect('error')
        return redirect('home')
    if request.session.has_key('UserId'):
        data1 = get_object_or_404(Register, UserId=request.session['UserId'])
        return render(request, 'AUTH/contact.html',{'data':data1})
    else:
        return render(request, 'AUTH/contact.html')



def Error_404(request):
    if request.session.has_key('UserId'):
        data1 = get_object_or_404(Register, UserId=request.session['UserId'])
        return render(request, 'AUTH/404.html',{'data':data1})
    else:
        return render(request,'AUTH/404.html')

