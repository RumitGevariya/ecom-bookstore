from django.db import models

# Create your models here.

class Register(models.Model):
    First_Name =models.CharField(max_length=200)
    Last_Name =models.CharField(max_length=200)
    Email =models.EmailField()
    Phone =models.CharField(max_length=200)
    Country =models.CharField(max_length=200)
    Address =models.TextField()
    City =models.CharField(max_length=200)
    State =models.CharField(max_length=200)
    PinCode =models.IntegerField()
    Password =models.CharField(max_length=200)
    Contact_States =models.CharField(max_length=200 ,default='False')
    UserId =models.CharField(max_length=200,default='')
    Profile_Image =models.ImageField(default='',blank=True,upload_to='profile_image')


class Contact(models.Model):
    Name =models.CharField(max_length=200)
    Email =models.EmailField()
    Subject =models.CharField(max_length=200)
    Message =models.TextField()

