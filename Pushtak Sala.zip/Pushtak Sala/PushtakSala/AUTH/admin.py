from django.contrib import admin
from .models import *
# Register your models here.

class MembersData(admin.ModelAdmin):
    list_display = ('UserId','First_Name','Last_Name','Email','Phone','Country', 'Address','City','State','PinCode','Password','Profile_Image','Contact_States')
    list_filter = ['Country','City','State','Contact_States']

admin.site.register(Register,MembersData)


class MemberData2(admin.ModelAdmin):
    list_display = ('Name','Email','Subject','Message')
    list_filter = ['Name','Subject']
admin.site.register(Contact, MemberData2)