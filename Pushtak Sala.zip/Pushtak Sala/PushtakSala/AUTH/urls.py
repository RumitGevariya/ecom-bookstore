from django.urls import path
from .views import *
urlpatterns = [
    path('login/',LOGIN_PAGE, name ='login'),
    path('register/',REGISTER_PAGE, name ='register'),
    path('myaccount/',MYACCOUNT_PAGE, name ='myaccount'),
    path('contact/',CONTACT_PAGE, name ='contact'),
    path('logout/',LOGOUT_PAGE ,name ='logout'),
    path('error404/',Error_404 ,name ='error'),
]