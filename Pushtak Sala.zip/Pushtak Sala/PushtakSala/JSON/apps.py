from django.apps import AppConfig


class JsonConfig(AppConfig):
    name = 'JSON'
