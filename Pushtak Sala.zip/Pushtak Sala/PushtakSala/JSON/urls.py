from django.urls import path,include
from rest_framework import routers
from . import views

router = routers.DefaultRouter()


router.register('register-data',views.Register_viewset)
router.register('contact-data',views.Contact_viewset)
router.register('books-data',views.Books_viewset)
router.register('bookscategories-data',views.BooksCategories_viewset)
router.register('cart-data',views.CART_viewset)
router.register('orderplacedetails-data',views.ORDER_PLACE_DETAILS_viewset)
router.register('blogcomments-data',views.Blog_Comments_viewset)

urlpatterns = [
    path('json/',include(router.urls))
]