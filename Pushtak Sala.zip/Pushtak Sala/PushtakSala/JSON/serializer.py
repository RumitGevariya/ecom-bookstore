from rest_framework import serializers
from AUTH.models import Register,Contact
from PRODUCT.models import Books,Books_Categories
from CART.models import CART, ORDER_PLACE_DETAILS,Blog_Comments

class Register_data(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Register
        fields = '__all__'

class Contact_data(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Contact
        fields ='__all__'

class BooksCategories_data(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Books_Categories
        fields ='__all__'

class Books_data(serializers.ModelSerializer):
    class Meta:
        model =Books
        fields ='__all__'

class CART_data(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = CART
        fields ='__all__'

class ORDER_PLACE_DETAILS_data(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = ORDER_PLACE_DETAILS
        fields ='__all__'

class Blog_Comments_data(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Blog_Comments
        fields ='__all__'