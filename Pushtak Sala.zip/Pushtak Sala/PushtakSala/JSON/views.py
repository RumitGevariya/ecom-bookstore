from django.shortcuts import render
from rest_framework import viewsets
from . import serializer
from AUTH.models import Register,Contact
from PRODUCT.models import Books,Books_Categories
from CART.models import CART, ORDER_PLACE_DETAILS,Blog_Comments

# Create your views here.

class Register_viewset(viewsets.ModelViewSet):
    queryset =Register.objects.all()
    serializer_class = serializer.Register_data

class Contact_viewset(viewsets.ModelViewSet):
    queryset =Contact.objects.all()
    serializer_class = serializer.Contact_data

class BooksCategories_viewset(viewsets.ModelViewSet):
    queryset =Books_Categories.objects.all()
    serializer_class = serializer.BooksCategories_data

class Books_viewset(viewsets.ModelViewSet):
    queryset =Books.objects.all()
    serializer_class = serializer.Books_data

class CART_viewset(viewsets.ModelViewSet):
    queryset =CART.objects.all()
    serializer_class = serializer.CART_data

class ORDER_PLACE_DETAILS_viewset(viewsets.ModelViewSet):
    queryset =ORDER_PLACE_DETAILS.objects.all()
    serializer_class = serializer.ORDER_PLACE_DETAILS_data

class Blog_Comments_viewset(viewsets.ModelViewSet):
    queryset =Blog_Comments.objects.all()
    serializer_class = serializer.Blog_Comments_data
