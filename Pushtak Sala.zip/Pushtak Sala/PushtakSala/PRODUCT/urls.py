from django.urls import path
from .views import *


urlpatterns = [
    path('book-details/<bookid>/',Single_Book, name ='bookdetails'),
    path('books/',Books_Page ,name ='books'),
    path('Romantic/',Romantic ,name ='Romance'),
    path('Drama/',Drama ,name ='Drama'),
]