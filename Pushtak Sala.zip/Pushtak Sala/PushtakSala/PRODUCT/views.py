from django.shortcuts import render, get_object_or_404
from django.db.models import Q
from .models import *
from AUTH.models import Register
from django.contrib import messages

# Create your views here.
def Single_Book(request, bookid):

    ###convert book details into audio..
    bookdetails = get_object_or_404(Books, pk=bookid)
    a = bookdetails.Book_Name
    try:
        Convert_Text_To_Audio(a, bookid)
        print("audio complated")
    except:
        pass
    ###play books details...
    if request.method == 'POST':
        from playsound import playsound
        playsound(f'media/gtts/{bookid}.mp3')
        print('play completed')

    if request.session.has_key('UserId'):
        profile = get_object_or_404(Register, UserId=request.session['UserId'])
        return render(request, 'PRODUCT/single.html', {'data': profile, 'bookdetails': bookdetails})
    else:
        return render(request, 'PRODUCT/single.html', {'bookdetails': bookdetails})



def Books_Page(request):
    All_Book = Books.objects.all()

    ###when user search somthing ......
    if request.method == 'POST':
        if request.POST.get('main') == 'main':
            global result
            result = request.POST.get('searchresult')
            find = Books.objects.filter(Q(Book_Publisher=result) | Q(Book_Author_Name=result))

            return render(request, 'PRODUCT/shop.html', {'All_Book': All_Book,'find': find, 'find_data': 'FIND_DATA'})
        else:
            try:
                price = request.POST.get('sortdata')
                if price == 'high':
                    sort = Books.objects.filter(Q(Book_Publisher=result) | Q(Book_Author_Name=result)).order_by('-Book_Offer_Price')
                else:
                    sort = Books.objects.filter(Q(Book_Publisher=result) | Q(Book_Author_Name=result)).order_by('Book_Offer_Price')
                return render(request, 'PRODUCT/shop.html', {'All_Book': All_Book,'sort': sort, 'sort_data': 'SORT_DATA'})
            except:
                price = request.POST.get('sortdata')
                if price == 'high':
                    sort = Books.objects.filter().order_by('-Book_Offer_Price')
                else:
                    sort = Books.objects.filter().order_by('Book_Offer_Price')
                return render(request, 'PRODUCT/shop.html', {'All_Book': All_Book,'sort': sort, 'sort_data': 'SORT_DATA'})


    if request.session.has_key('UserId'):
        profile = get_object_or_404(Register, UserId=request.session['UserId'])
        return render(request, 'PRODUCT/shop.html', {'data': profile,'All_Book': All_Book})
    else:
        return render(request, 'PRODUCT/shop.html', {'All_Book': All_Book})


def Romantic(request):
    All_Book = Books.objects.all()
    romantic_books = Books.objects.filter(Books_Data__Categories_name='Romance')

    ###when user search somthing ......
    if request.method == 'POST':
        if request.POST.get('main') == 'main':
            global results
            results = request.POST.get('searchresult')
            find = Books.objects.filter((Q(Book_Publisher=results) | Q(Book_Author_Name=results)) & Q(Books_Data__Categories_name='Romance'))
            return render(request, 'PRODUCT/shop.html', {'find': find, 'find_data': 'FIND_DATA'})
        else:
            try:
                sort = request.POST.get('sortdata')
                if sort =='high':
                    sort = Books.objects.filter((Q(Book_Publisher=results) | Q(Book_Author_Name=results)) &Q(Books_Data__Categories_name='Romance')).order_by('-Book_Offer_Price')
                else:
                    sort = Books.objects.filter((Q(Book_Publisher=results) | Q(Book_Author_Name=results)) & Q(Books_Data__Categories_name='Romance')).order_by('Book_Offer_Price')
                return render(request, 'PRODUCT/shop.html', {'sort': sort,'sort_data': 'SORT_DATA'})
            except:
                sort = request.POST.get('sortdata')
                if sort == 'high':
                    sort = Books.objects.filter(Q(Books_Data__Categories_name='Romance')).order_by('-Book_Offer_Price')
                else:
                    sort = Books.objects.filter(Q(Books_Data__Categories_name='Romance')).order_by('Book_Offer_Price')
                return render(request, 'PRODUCT/shop.html', {'sort': sort, 'sort_data': 'SORT_DATA'})


    if request.session.has_key('UserId'):
        profile = get_object_or_404(Register, UserId=request.session['UserId'])
        return render(request, 'PRODUCT/shop.html', {'data': profile,'romance_books': romantic_books,'Romantic':'romantic','All_Book': All_Book})
    else:
        return render(request, 'PRODUCT/shop.html', {'romance_books': romantic_books, 'Romantic':'romantic','All_Book': All_Book})


def Drama(request):
    All_Book = Books.objects.all()
    Drama_books = Books.objects.filter(Books_Data__Categories_name='Drama')

    ###when user search somthing ......
    if request.method == 'POST':
        if request.POST.get('main') == 'main':
            global results
            results = request.POST.get('searchresult')
            find = Books.objects.filter((Q(Book_Publisher=results) | Q(Book_Author_Name=results)) & Q(Books_Data__Categories_name='Drama'))
            return render(request, 'PRODUCT/shop.html', {'find': find, 'find_data': 'FIND_DATA'})
        else:
            try:
                sort = request.POST.get('sortdata')
                if sort == 'high':
                    sort = Books.objects.filter((Q(Book_Publisher=results) | Q(Book_Author_Name=results)) & Q(Books_Data__Categories_name='Drama')).order_by('-Book_Offer_Price')
                else:
                    sort = Books.objects.filter((Q(Book_Publisher=results) | Q(Book_Author_Name=results)) & Q(Books_Data__Categories_name='Drama')).order_by('Book_Offer_Price')
                return render(request, 'PRODUCT/shop.html', {'sort': sort, 'sort_data': 'SORT_DATA'})
            except:
                sort = request.POST.get('sortdata')
                if sort == 'high':
                    sort = Books.objects.filter(Q(Books_Data__Categories_name='Drama')).order_by('-Book_Offer_Price')
                else:
                    sort = Books.objects.filter(Q(Books_Data__Categories_name='Drama')).order_by('Book_Offer_Price')
                return render(request, 'PRODUCT/shop.html', {'sort': sort, 'sort_data': 'SORT_DATA'})

    if request.session.has_key('UserId'):
        profile = get_object_or_404(Register, UserId=request.session['UserId'])
        return render(request, 'PRODUCT/shop.html',{'data': profile, 'drama_books': Drama_books, 'Drama': 'drama', 'All_Book': All_Book})
    else:
        return render(request, 'PRODUCT/shop.html',{'drama_books': Drama_books,  'Drama': 'drama', 'All_Book': All_Book})



def Convert_Text_To_Audio(b,bookid):
    from gtts import gTTS
    a =gTTS(b)
    print("he")
    a.save(f'media/gtts/{bookid}.mp3')

