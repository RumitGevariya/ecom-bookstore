from django.contrib import admin
from .models import *

class AdminCategories(admin.ModelAdmin):
    list_display = ['Categories_name']
admin.site.register(Books_Categories, AdminCategories)

# Register your models here.
class AdminProducts(admin.ModelAdmin):
    list_display = ['Books_Data','Book_Image','Book_Name','Book_Offer_Price',
                    'Book_Author_Name' ,'Book_Actual_Price','Book_Publisher','Book_Language','Book_Total_Pages','Book_Published_year',]
    list_filter = ['Books_Data','Book_Name','Book_Publisher', 'Book_Author_Name','Book_Published_year']
admin.site.register(Books,AdminProducts)