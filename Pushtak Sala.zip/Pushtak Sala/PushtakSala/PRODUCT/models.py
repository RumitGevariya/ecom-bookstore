from django.db import models

# Create your models here.
class Books_Categories(models.Model):
    Categories_name =models.CharField(max_length=200)

    def __str__(self):
        return self.Categories_name

class Books(models.Model):
    Books_Data =models.ForeignKey(Books_Categories,on_delete=models.CASCADE,default=1)
    Book_Image =models.ImageField(upload_to='Rumit')
    Book_Name =models.CharField(max_length=100)
    Book_Offer_Price =models.FloatField(default=0)
    Book_Actual_Price =models.FloatField(default=0)
    Book_Author_Name =models.CharField(max_length=200,default='')
    Book_Publisher =models.CharField(max_length=200,default='')
    Book_Language =models.CharField(max_length=200,default='')
    Book_Total_Pages =models.PositiveIntegerField(default=0)
    Book_Published_year =models.CharField(max_length=200,default='')
    Book_Details =models.TextField(default='')

